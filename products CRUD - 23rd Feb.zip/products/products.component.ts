import { Component } from '@angular/core';


@Component({
  selector: 'app-products',  //app - is prefix 
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent  {

  pid:number
  pname:string
  pprice  //default any 
  products
  constructor()  {

    this.products =[]

  }


  takeID(event){

    console.log("id")

    this.pid = event.target.value

  }



  takeName(event){
    console.log("name")

    this.pname = event.target.value



      }


  takePrice(event){
    console.log("price")
  this.pprice = event.target.value

  console.log(this.pprice)
      }



 AddProduct(){
    
  console.log("button")

  this.products.push({pid:this.pid,pname:this.pname,pprice:this.pprice});
  console.log(this.products);

  

      }

del(ind){

  console.log('clcked on del ',ind);
  this.products.splice(ind,1);
  

}
}
