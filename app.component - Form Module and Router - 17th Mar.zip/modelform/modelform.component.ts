import { Component, OnInit } from '@angular/core';

import {FormGroup,FormControl} from   '@angular/forms';

@Component({
  selector: 'app-modelform',
  templateUrl: './modelform.component.html',
  styleUrls: ['./modelform.component.css']
})
export class ModelformComponent implements OnInit {

  frm:FormGroup;
  name:string;
  
  constructor() { }

  ngOnInit() {

    this.frm = new FormGroup({
         
          phone: new FormControl(),
          pwd: new FormControl() ,  
          fname: new FormControl(),
          lname: new FormControl(),
          email: new FormControl()  
    });
  }
  frm_submit(){

    console.log(this.frm.value);


  }

}
