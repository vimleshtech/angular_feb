import { Component,OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { MyutilsService } from 'src/app/myutils.service';

import { productModel } from 'src/app/models/productModel';

import { Observable } from 'rxjs/internal/Observable';

import { trigger, state, style, transition, animate } from '@angular/animations';

//import {EmployeeModel} from './models/empModel'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  styles:[`
  // div{
  //    margin: 0 auto;
  //    text-align: center;
  //    width:200px;
  // }
  .rotate{
     width:100px;
     height:100px;
     border:solid 1px red;
  }
`],
animations: [
  trigger('myanimation',[
     state('smaller',style({
        transform : 'translateX(100px)'
     })),
     state('larger',style({
        transform : 'translateX(0px)'
     })),
     transition('smaller <=> larger',animate('5s'))
  ])
]

})
export class AppComponent  implements OnInit  {
  
  title = 'app'
  name ='Raman Sinha';
  email
  lists
  data_1 = ["raman","jatin","aman"]  
  emps
  count 
  //em:EmployeeModel

  state: string = "smaller";
  
  animate() {
     this.state= this.state == 'larger' ? 'smaller' : 'larger';
  }


  constructor(private http:HttpClient,private serObj: MyutilsService,
    )
  {
    this.lists=[]
    this.emps = []

  }

  displayCounter(count) {
    
    var p = new productModel(11,"lakme",3333)
    p.isMarked = true;
    
    console.log(count);
    this.count = count 
    alert(count);

    
  }


calcSal()
{
 //var tax =  this.serObj.incomeTax(44444333);
 //alert(tax);

 //var o = new MyutilsService();
 //o.incomeTax(111);


}
  ngOnInit()
  {


    const locations = new Observable ((observer) => {
      // When the consumer unsubscribes, clean up data ready for next subscription.
      return {unsubscribe() { "test" }};
    });


    const locationsSubscription = locations.subscribe({
      next(position) { console.log('Current Position: ', position); },
      error(msg) { console.log('Error Getting Location: ', msg); }
    });

  console.log(locationsSubscription)   ;


    //read 
    /*
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(res => res.json())
    .then(out => this.lists= out)
    */

     this.http.get("https://jsonplaceholder.typicode.com/posts/2")
     .subscribe((data) =>  {
       //this.lists.push(data);
       this.lists = data;
       console.log(data);
       });

    
    //post 
    var a,b;
    a =333;
    b =44;
    //https://mail.google.com/mail/?tab=wm
    // //pass data via query sting 
    // fetch('https://jsonplaceholder.typicode.com/posts?k1='+a+'&k2='+b)
    // .then(res => res.json())
    // .then(out => this.lists= out)

    //or 

    // fetch('https://jsonplaceholder.typicode.com/posts',
    //   {
    //       method:'post',
    //       body:a,

    //   }
    // )
    // .then(res => res.json())
    // .then(out => this.lists= out)
    
    
  }

  readName(event)
  {
    this.name = event.target.value

  }

  readEmail(event)
  {
    this.email = event.target.value
    
  }
  add()
  {
    this.emps.push({name:this.name,email:this.email})
  }


  
}
class test
{

}

