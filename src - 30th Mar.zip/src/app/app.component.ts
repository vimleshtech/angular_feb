import { Component } from '@angular/core';
import { Customer } from 'src/app/models/Customer';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  title = 'live-project Example ';

  constructor(private obj:Customer ){

  }
  getData(){

   
    
      console.log(this.obj.getCustomer());

  }
  setData(){
    
          this.obj.addCustomer(100,'Nitin','male');
    
        
   
    
      }
}
