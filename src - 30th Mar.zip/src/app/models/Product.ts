

export class Product{
    
        private pid:number;
        private pname:string;
        private pprice:number;
        private isMark:boolean;
    
        constructor(){
        }
    
    
        addProduct(pid:number,pname:string,pprice?:number){ //pprice?:number : is nuable 
    
            this.pid = pid;
            this.pname  = pname;
            this.pprice = pprice;
            this.isMark=false;
        }
        toggle(){
            this.isMark =!this.isMark;
        }
        getProduct(){
         
            return {pid:this.pid,pname:this.pname,pprice:this.pprice,ismark:this.isMark};
    
        }
    }
    