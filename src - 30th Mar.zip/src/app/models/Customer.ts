
export class Customer{
    
        private cid:number;
        private cname:string;
        private gender:string;
        private isMark:boolean;
    
        constructor(){
        }
    
    
        addCustomer(id:number,name:string,gender:string){ //pprice?:number : is nuable 
    
            this.cid = id;
            this.cname  = name;
            this.gender = gender;
            this.isMark=false;
        }
        toggle(){
            this.isMark =!this.isMark;
        }
        getCustomer(){
         
            return {cid:this.cid,cname:this.cname,gender:this.gender,ismark:this.isMark};
    
        }
    }
    